import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { FinanceService } from '../services/finance.service';
import { UserService } from '../services/user';
import { User } from '../models/user.model';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  standalone: true,                       
  imports: [CommonModule, FormsModule, RouterModule]    
})
export class UserComponent implements OnInit {
  user!: User;
  finance = inject(FinanceService);
  isEditing = false;
  editData: User = { id: 1, name: '', email: '', phone: '' };

  balance = 12450;
  income = 5800;
  tempBalance!: number;
  tempIncome!: number;
  newSubName = '';
  newSubCost = 0;
  pendingDeleteSubscription: string | null = null;

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.userService.currentUser.subscribe(data => {
      this.user = data;
    });
  }

  get initials(): string {
    return this.user?.name.split(' ').map(n => n[0]).join('').toUpperCase();
  }

  startEdit() {
    this.editData = { ...this.user };
    this.isEditing = true;
  }

  saveEdit() {
    this.userService.updateUser(this.editData);
    this.isEditing = false;
  }

  cancelEdit() { this.isEditing = false; }

  saveFinancials() {
    if (this.tempBalance) this.balance = this.tempBalance;
    if (this.tempIncome)  this.income  = this.tempIncome;
    this.tempBalance = this.tempIncome = 0;
  }

  addSubscriptionPlan(): void {
    if (!this.newSubName.trim() || this.newSubCost <= 0) return;
    this.finance.addSubscriptionPlan(this.newSubName.trim(), this.newSubCost);
    this.newSubName = '';
    this.newSubCost = 0;
  }

  requestDeleteSubscription(name: string): void {
    this.pendingDeleteSubscription = name;
  }

  cancelDeleteSubscription(): void {
    this.pendingDeleteSubscription = null;
  }

  confirmDeleteSubscription(): void {
    if (!this.pendingDeleteSubscription) return;
    this.finance.deleteSubscriptionPlan(this.pendingDeleteSubscription);
    this.pendingDeleteSubscription = null;
  }
}
