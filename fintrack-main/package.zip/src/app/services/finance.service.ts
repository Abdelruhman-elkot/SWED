import { Injectable, signal, computed } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Transaction, Subscription, TransactionType } from '../models/transaction.model';

@Injectable({ providedIn: 'root' })
export class FinanceService {

  readonly catIcons: Record<string, string> = {
    Food: '🛒', Rent: '🏠', Transport: '🚗',
    Entertainment: '🎬', Subscription: '🎵', Income: '💰', Other: '📦'
  };

  readonly catBg: Record<string, string> = {
    Food: '#1a2e1a', Rent: '#1a1f2e', Transport: '#2e1a1a',
    Entertainment: '#1a1a2e', Subscription: '#2e1e0d', Income: '#0d2318', Other: '#1a1a1a'
  };

  private nextId = 8;

  private initialTransactions: Transaction[] = [
    { id: 1, name: 'Grocery Shopping',  category: 'Food',         type: 'expense',      amount: 124.50, date: 'Apr 21', icon: '🛒', iconBg: '#1a2e1a' },
    { id: 2, name: 'Monthly Rent',      category: 'Rent',         type: 'expense',      amount: 963.00, date: 'Apr 20', icon: '🏠', iconBg: '#1a1f2e' },
    { id: 3, name: 'Salary Deposit',    category: 'Income',       type: 'income',       amount: 5800.00,date: 'Apr 20', icon: '💰', iconBg: '#0d2318' },
    { id: 4, name: 'Uber Rides',        category: 'Transport',    type: 'expense',      amount: 48.20,  date: 'Apr 19', icon: '🚗', iconBg: '#2e1a1a' },
    { id: 5, name: 'Netflix',           category: 'Subscription', type: 'subscription', amount: 15.99,  date: 'Apr 18', icon: '🎬', iconBg: '#1a1a2e' },
    { id: 6, name: 'Restaurant Dinner', category: 'Food',         type: 'expense',      amount: 67.30,  date: 'Apr 17', icon: '🍕', iconBg: '#1a2a1a' },
    { id: 7, name: 'Spotify',           category: 'Subscription', type: 'subscription', amount: 9.99,   date: 'Apr 15', icon: '🎵', iconBg: '#2e1e0d' },
  ];

  private initialSubscriptions: Subscription[] = [
    { name: 'Netflix',     icon: '🎬', iconBg: '#1a1a2e', price: 15.99, renewDate: 'May 18', frequency: 'monthly' },
    { name: 'Spotify',     icon: '🎵', iconBg: '#2e1e0d', price: 9.99,  renewDate: 'May 15', frequency: 'monthly' },
    { name: 'iCloud 200GB',icon: '☁️', iconBg: '#0d1f2e', price: 2.99,  renewDate: 'May 1',  frequency: 'monthly' },
    { name: 'Adobe CC',    icon: '📊', iconBg: '#1a2e20', price: 54.99, renewDate: 'May 10', frequency: 'monthly' },
  ];

  private transactionsSubject = new BehaviorSubject<Transaction[]>(this.initialTransactions);
  private subscriptionsSubject = new BehaviorSubject<Subscription[]>(this.initialSubscriptions);

  transactions = signal<Transaction[]>(this.transactionsSubject.value);
  subscriptions = signal<Subscription[]>(this.subscriptionsSubject.value);

  transactions$ = this.transactionsSubject.asObservable();
  subscriptions$ = this.subscriptionsSubject.asObservable();

  budget = signal(4200);

  balance = computed(() => this.totalIncome() - this.totalSpent());

  totalSpent = computed(() =>
    this.transactions().filter(t => t.type !== 'income').reduce((s, t) => s + t.amount, 0)
  );

  totalIncome = computed(() =>
    this.transactions().filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
  );

  totalSubscriptions = computed(() =>
    this.subscriptions().reduce((sum, sub) => sum + sub.price, 0)
  );

  budgetRemaining = computed(() => this.budget() - this.totalSpent());

  activeSubscriptionsCount = computed(() => this.subscriptions().length);

  recentTransactions = computed(() => [...this.transactions()].slice(0, 5));

  private updateTransactions(list: Transaction[]): void {
    this.transactions.set(list);
    this.transactionsSubject.next(list);
  }

  private updateSubscriptions(list: Subscription[]): void {
    this.subscriptions.set(list);
    this.subscriptionsSubject.next(list);
  }

  private upsertSubscription(name: string, price: number, icon: string, iconBg: string): void {
    const normalizedName = name.trim().toLowerCase();
    const renewDate = this.buildRenewDate();
    const list = this.subscriptions();
    const existingIdx = list.findIndex(sub => sub.name.trim().toLowerCase() === normalizedName);

    if (existingIdx === -1) {
      this.updateSubscriptions([{ name, price, icon, iconBg, renewDate, frequency: 'monthly' }, ...list]);
      return;
    }

    this.updateSubscriptions(list.map((sub, idx) =>
      idx === existingIdx ? { ...sub, name, price, icon, iconBg, renewDate, frequency: 'monthly' } : sub
    ));
  }

  private removeSubscriptionIfUnused(name: string): void {
    const normalizedName = name.trim().toLowerCase();
    const stillExists = this.transactions().some(
      txn => txn.type === 'subscription' && txn.name.trim().toLowerCase() === normalizedName
    );
    if (stillExists) return;

    this.updateSubscriptions(this.subscriptions().filter(sub => sub.name.trim().toLowerCase() !== normalizedName));
  }

  addSubscriptionPlan(name: string, price: number): void {
    const icon = this.catIcons['Subscription'] || '🎵';
    const iconBg = this.catBg['Subscription'] || '#2e1e0d';
    this.upsertSubscription(name, price, icon, iconBg);
  }

  deleteSubscriptionPlan(name: string): void {
    const normalizedName = name.trim().toLowerCase();
    this.updateSubscriptions(this.subscriptions().filter(
      sub => sub.name.trim().toLowerCase() !== normalizedName
    ));
  }

  private buildRenewDate(): string {
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    return nextMonth.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  addTransaction(name: string, amount: number, type: TransactionType, category: string): void {
    const icon = this.catIcons[category] || '📦';
    const iconBg = this.catBg[category] || '#1a1a1a';
    const newTxn: Transaction = {
      id: this.nextId++, name, category, type, amount,
      date: 'Today', icon, iconBg
    };
    this.updateTransactions([newTxn, ...this.transactions()]);

    const isSubscription = type === 'subscription' || category === 'Subscription';
    if (isSubscription) {
      this.upsertSubscription(name, amount, icon, iconBg);
    }
  }

  updateTransaction(id: number, name: string, amount: number, type: TransactionType, category: string): void {
    const current = this.transactions().find(t => t.id === id);
    if (!current) return;

    const icon = this.catIcons[category] || '📦';
    const iconBg = this.catBg[category] || '#1a1a1a';

    this.updateTransactions(this.transactions().map(t =>
      t.id === id
        ? { ...t, name, amount, type, category, icon, iconBg }
        : t
    ));

    const wasSubscription = current.type === 'subscription' || current.category === 'Subscription';
    const isSubscription = type === 'subscription' || category === 'Subscription';

    if (wasSubscription) {
      this.removeSubscriptionIfUnused(current.name);
    }
    if (isSubscription) {
      this.upsertSubscription(name, amount, icon, iconBg);
    }
  }

  deleteTransaction(id: number): void {
    const txn = this.transactions().find(t => t.id === id);
    if (txn) {
      this.updateTransactions(this.transactions().filter(t => t.id !== id));
      if (txn.type === 'subscription') {
        this.removeSubscriptionIfUnused(txn.name);
      }
    }
  }
}
